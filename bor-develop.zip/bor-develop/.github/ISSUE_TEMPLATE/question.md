---
name: Question/Support
about: Ask a question or request support
title: ''
labels: 'type:docs'
assignees: ''
---

This should only be used in very rare cases e.g. if you are not 100% sure if something is a bug or asking a question that leads to improving the documentation. 

For general questions please join our [discord](https://discord.com/invite/zdwkdvMNY2) server.
